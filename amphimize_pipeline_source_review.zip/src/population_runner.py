"""
population_runner.py

Generates candidate peptides using the native C backend or controlled
Python mutation policies.

ARISE's mutation-credit mode learns from eligible, explicitly recorded
parent-child score changes. A missing or invalid structural reward is never
replaced silently with sequence-level fitness.

Modes:
    legacy                  Existing native C mutation generator.
    uniform_matched         Fixed-budget uniform mutation baseline.
    mutation_credit         Fixed-budget mutation-credit adaptive search.
    uniform                 Existing ALE uniform policy.
    hotspot_only            Existing ALE hotspot-only policy.
    hotspot_biased          Existing ALE hotspot-biased policy.
    hotspot_biased_annealed Existing ALE annealed hotspot policy.
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict
from typing import Any

from c.bridge import (
    generate_c_population,
    generate_policy_population,
    process_candidate_peptide,
)

from src.ale_policy import resolve_mutation_policy, mutation_positions
from src.config import (
    ARISE_ENABLED,
    DIVERSITY_REFILL_ATTEMPTS,
    GENERATIONS,
    MUTATION_RATE,
    POPULATION_SIZE,
    REMOVE_DUPLICATE_CANDIDATES,
)
from src.models import Candidate
from src.epistasis_entropy import (
    EpistasisEntropyController,
    PAIRWISE_MODES,
)
from src.mutation_credit import (
    MutationCreditARISE,
    generate_position_weighted_population,
    mutation_event_budget,
)

logger = logging.getLogger(__name__)


# ==========================================================
# Legacy diagnostic: sequence-position association
# ==========================================================

def estimate_position_effects(
    sequences: list[str],
    scores: list[float],
    *,
    min_group_size: int = 3,
    shrinkage: float = 5.0,
) -> dict[int, float]:
    """
    Estimate the strength of the association between residue identity
    at each position and scores in the supplied candidate set.

    This is an observational association, not a causal mutation effect
    and not evidence of target binding. It is retained for compatibility
    and analysis; mutation_credit mode does not use it as its reward.
    """
    if len(sequences) != len(scores):
        raise ValueError("sequences and scores must have equal length")

    if not sequences:
        return {}

    if min_group_size < 2 or shrinkage < 0:
        raise ValueError("invalid estimator parameters")

    try:
        numeric_scores = [float(score) for score in scores]
    except (TypeError, ValueError) as exc:
        raise ValueError("scores must be numeric and finite") from exc

    if any(not math.isfinite(score) for score in numeric_scores):
        raise ValueError("scores must be finite")

    if any(not isinstance(seq, str) or not seq for seq in sequences):
        raise ValueError("sequences must be nonempty strings")

    normalized_sequences = [seq.upper() for seq in sequences]
    length = len(normalized_sequences[0])

    if any(len(seq) != length for seq in normalized_sequences):
        raise ValueError("all sequences must have equal length")

    ordered = sorted(numeric_scores)

    def quantile(q: float) -> float:
        index = q * (len(ordered) - 1)
        lo = int(index)
        hi = min(lo + 1, len(ordered) - 1)
        fraction = index - lo
        return (
            ordered[lo] * (1.0 - fraction)
            + ordered[hi] * fraction
        )

    median = quantile(0.5)
    scale = max(quantile(0.75) - quantile(0.25), 1e-8)

    standardized = [
        max(-3.0, min(3.0, (score - median) / scale))
        for score in numeric_scores
    ]

    overall = sum(standardized) / len(standardized)
    total_ss = sum((score - overall) ** 2 for score in standardized)

    if total_ss <= 1e-12:
        return {position: 0.0 for position in range(length)}

    effects: dict[int, float] = {}

    for position in range(length):
        groups: dict[str, list[float]] = defaultdict(list)

        for sequence, score in zip(normalized_sequences, standardized):
            groups[sequence[position]].append(score)

        eligible = [
            values
            for values in groups.values()
            if len(values) >= min_group_size
        ]

        if len(eligible) < 2:
            effects[position] = 0.0
            continue

        between_ss = 0.0

        for values in eligible:
            count = len(values)
            group_mean = sum(values) / count
            reliability = count / (count + shrinkage)
            shrunk_mean = overall + reliability * (group_mean - overall)
            between_ss += count * (shrunk_mean - overall) ** 2

        effects[position] = math.sqrt(
            max(0.0, min(1.0, between_ss / total_ss))
        )

    return effects


# ==========================================================
# ARISE mutation-credit engine
# ==========================================================

# The public ARISE_ENGINE name points to the mutation-credit learner.
# Its observe_generation() method accepts only candidates carrying
# explicitly validated, comparable reward metadata.
ARISE_ENGINE = MutationCreditARISE(
    reward_source="validated_target_structural",
    memory_decay=0.90,
    exploration_floor=0.25,
    exploration_c=1.0,
)
# Backward-compatible import name used by existing tests and modules.
ARISEEngine = MutationCreditARISE


# ==========================================================
# Population generation
# ==========================================================

CONTROLLED_MODES = {
    "uniform_matched",
    "mutation_credit",
}

VALID_MODES = {
    "legacy",
    "uniform_matched",
    "mutation_credit",
    "uniform",
    "hotspot_only",
    "hotspot_biased",
    "hotspot_biased_annealed",
    "hotspot_biased_annealed_exploratory",
} | set(PAIRWISE_MODES)


def generate_candidates(
    seed_sequence: str,
    population_size: int = POPULATION_SIZE,
    mutation_rate: float = MUTATION_RATE,
    arise_enabled: bool = ARISE_ENABLED,
    cache_enabled: bool = True,
    hotspot_model: dict | None = None,
    hotspot_enabled: bool = False,
    ale_enabled: bool = False,
    mutation_guidance_mode: str = "legacy",
    generation: int = 1,
    run_id: str = "",
    preserve_sequence: str | None = None,
    total_generations: int | None = None,
    random_seed: int | None = None,
    operator_controller: EpistasisEntropyController | None = None,
    initial_sequences: list[str] | None = None,
) -> list[Candidate]:
    """
    Generate and evaluate a population of candidate peptides.

    Controlled comparisons:
        uniform_matched:
            Uses uniform position probabilities with a fixed event budget.

        mutation_credit:
            Uses ARISE's learned position probabilities with the same
            fixed event budget, alphabet, and replacement rule.

    Both controlled modes differ only in the distribution used to select
    mutation positions. The mutation-credit mode learns only when valid,
    comparable parent-child structural reward metadata is supplied by the
    downstream scoring/evaluation layer.

    random_seed:
        Optional deterministic seed. Use the same seed for the baseline and
        adaptive arms of each paired experiment.
    """
    if not isinstance(seed_sequence, str) or not seed_sequence:
        raise ValueError("seed_sequence must be a nonempty string")

    seed_sequence = seed_sequence.upper()

    if population_size <= 0:
        raise ValueError("population_size must be positive")

    if not math.isfinite(float(mutation_rate)):
        raise ValueError("mutation_rate must be finite")

    if not 0.0 <= mutation_rate <= 1.0:
        raise ValueError("mutation_rate must be between 0 and 1")

    if mutation_guidance_mode not in VALID_MODES:
        raise ValueError(
            "Unknown mutation_guidance_mode: "
            f"{mutation_guidance_mode!r}. Valid modes: "
            f"{', '.join(sorted(VALID_MODES))}"
        )

    if (
        mutation_guidance_mode == "mutation_credit"
        and not arise_enabled
    ):
        raise ValueError(
            "mutation_credit mode requires arise_enabled=True"
        )

    total_generations = total_generations or GENERATIONS

    if total_generations <= 0:
        raise ValueError("total_generations must be positive")

    if generation <= 0:
        raise ValueError("generation must be positive")

    mode = mutation_guidance_mode

    logger.info(
        "Generating candidates | mode=%s | generation=%d/%d | "
        "population_size=%d | mutation_rate=%.4f | random_seed=%s",
        mode,
        generation,
        total_generations,
        population_size,
        mutation_rate,
        random_seed,
    )

    if mode in PAIRWISE_MODES:
        if operator_controller is None:
            raise ValueError(
                f"{mode} requires an EpistasisEntropyController"
            )

        selected = (hotspot_model or {}).get("selected_hotspot")
        hotspot_validated = bool(
            selected
            and (hotspot_model or {}).get(
                "hotspot_significance_validated"
            ) is True
        )
        apply_hotspot = bool(
            mode in {
                "hotspot_epistasis_entropy",
                "hotspot_epistasis_entropy_exploratory",
                "hotspot_entropy_substitution_epistasis_exploratory",
                "hotspot_entropy_substitution_epistasis_exploratory_v2",
                "hotspot_entropy_substitution_epistasis_exploratory_v2_matched",
            }
            and selected
            and (
                hotspot_validated
                or mode in {
                    "hotspot_epistasis_entropy_exploratory",
                    "hotspot_entropy_substitution_epistasis_exploratory",
                    "hotspot_entropy_substitution_epistasis_exploratory_v2",
                    "hotspot_entropy_substitution_epistasis_exploratory_v2_matched",
                }
            )
        )
        hotspot_start = (
            int(selected["start_position"]) if apply_hotspot else None
        )
        hotspot_end = (
            int(selected["end_position"]) if apply_hotspot else None
        )

        policy: dict[str, Any] = {
            "requested_mode": mode,
            "mode": mode,
            "guided": apply_hotspot,
            "hotspot_start": hotspot_start,
            "hotspot_end": hotspot_end,
            "hotspot_discovery_generation": (
                (hotspot_model or {}).get("discovery_generation")
                if apply_hotspot else None
            ),
            # None means not applicable: this method uses a weight multiplier,
            # not the legacy probability-of-guidance schedule.
            "hotspot_probability": None if apply_hotspot else 0.0,
            "hotspot_weight_multiplier": (1.25 if mode in {"hotspot_entropy_substitution_epistasis_exploratory", "hotspot_entropy_substitution_epistasis_exploratory_v2"} else 2.0) if apply_hotspot else 1.0,
            "hotspot_guidance_evidence_status": (
                "validated" if hotspot_validated
                else "exploratory_unvalidated" if apply_hotspot
                else "not_used"
            ),
            "hotspot_positions_used": (
                list(range(hotspot_start, hotspot_end))
                if apply_hotspot else []
            ),
        }
        probabilities = None

    elif mode in CONTROLLED_MODES:
        policy = {
            "requested_mode": mode,
            "mode": mode,
            "guided": mode == "mutation_credit",
            "hotspot_start": None,
            "hotspot_end": None,
            "hotspot_discovery_generation": None,
            "hotspot_probability": 0.0,
        }

        if mode == "uniform_matched":
            probabilities = None
        else:
            probabilities = ARISE_ENGINE.position_probabilities(
                len(seed_sequence)
            )

        logger.info(
            "Controlled mutation policy | mode=%s | budget=%d",
            mode,
            mutation_event_budget(len(seed_sequence), mutation_rate),
        )

    else:
        probabilities = None

        policy = resolve_mutation_policy(
            "uniform" if mode == "legacy" else mode,
            hotspot_model,
            enabled=hotspot_enabled and ale_enabled,
            generation=generation,
            total_generations=total_generations,
        )

        if mode != "legacy":
            logger.info(
                "ALE policy | requested=%s | active=%s | guided=%s | "
                "hotspot=%s:%s | hotspot_probability=%.3f",
                policy["requested_mode"],
                policy["mode"],
                policy["guided"],
                policy["hotspot_start"],
                policy["hotspot_end"],
                policy["hotspot_probability"],
            )

    # Candidate generation can be retried when duplicate removal is active.
            # Candidate generation can be retried when duplicate removal is active.
    # Initialize this BEFORE defining and calling generate_batch.
    attempts = 0

    def generate_batch(size: int) -> list[str]:
        nonlocal attempts

        if mode in PAIRWISE_MODES:
            if operator_controller is None:
                raise RuntimeError(
                    f"Missing controller for pairwise mode: {mode}"
                )

            batch_seed = (
                None
                if random_seed is None
                else (
                    int(random_seed)
                    + generation * 1_000_003
                    + attempts
                )
            )

            protected_positions: set[int] = set()
            hotspot_positions: set[int] = set()
            selected = (hotspot_model or {}).get("selected_hotspot")

            # Only the explicitly combined method may consume hotspot data.
            # In particular, do not protect hotspot positions in the entropy
            # ablation: that would silently change its entropy weights.
            if (
                mode in {
                    "hotspot_epistasis_entropy",
                    "hotspot_epistasis_entropy_exploratory",
                    "hotspot_entropy_substitution_epistasis_exploratory",
                    "hotspot_entropy_substitution_epistasis_exploratory_v2",
                    "hotspot_entropy_substitution_epistasis_exploratory_v2_matched",
                }
                and selected
                and (
                    (hotspot_model or {}).get(
                        "hotspot_significance_validated"
                    ) is True
                    or mode in {
                        "hotspot_epistasis_entropy_exploratory",
                        "hotspot_entropy_substitution_epistasis_exploratory",
                        "hotspot_entropy_substitution_epistasis_exploratory_v2",
                        "hotspot_entropy_substitution_epistasis_exploratory_v2_matched",
                    }
                )
            ):
                start = int(selected["start_position"])
                end = int(selected["end_position"])
                hotspot_positions.update(range(start, end))

            population = operator_controller.generate_population(
                seed_sequence,
                pop_size=size,
                seed=batch_seed,
                mode=mode,
                protected_positions=protected_positions,
                hotspot_positions=hotspot_positions,
                hotspot_boost=(
                    1.25
                    if mode in {"hotspot_entropy_substitution_epistasis_exploratory", "hotspot_entropy_substitution_epistasis_exploratory_v2"}
                    else 2.0
                ),
            )

            logger.info(
                "Pair-selection telemetry | generation=%d | mode=%s | "
                "hotspot_positions=%s | hotspot_boost=%.2f | "
                "top_weights=%s | selected_pairs=%s | selected_substitutions=%s",
                generation,
                mode,
                sorted(hotspot_positions),
                2.0 if hotspot_positions else 1.0,
                [
                    (pair, round(weight, 8))
                    for pair, weight
                    in operator_controller.last_pair_weights
                ],
                operator_controller.last_selected_pairs,
                operator_controller.last_selected_substitutions,
            )
            return population

        if mode in CONTROLLED_MODES:
            batch_seed = (
                None
                if random_seed is None
                else (
                    int(random_seed)
                    + generation * 1_000_003
                    + attempts
                )
            )

            return generate_position_weighted_population(
                seed_sequence,
                pop_size=size,
                mutation_rate=mutation_rate,
                probabilities=probabilities,
                seed=batch_seed,
            )

        if mode == "legacy":
            return generate_c_population(
                seed_sequence,
                pop_size=size,
                mutation_rate=mutation_rate,
            )

        return generate_policy_population(
            seed_sequence,
            mutation_rate=mutation_rate,
            guidance_mode=policy["mode"],
            hotspot_start=policy["hotspot_start"],
            hotspot_end=policy["hotspot_end"],
            pop_size=size,
            hotspot_probability=policy["hotspot_probability"],
        )
                    # Generate population and remove duplicates if required.
    sequences: list[str] = []
    seen: set[str] = set()

    if initial_sequences is not None:
        normalized = [
            str(sequence).strip().upper()
            for sequence in initial_sequences
        ]

        if len(normalized) != population_size:
            raise ValueError(
                "Initial pool size must equal population_size: "
                f"{len(normalized)} != {population_size}"
            )

        if len(set(normalized)) != len(normalized):
            raise ValueError("Initial pool contains duplicate sequences.")

        canonical = set("ACDEFGHIKLMNPQRSTVWY")
        for sequence in normalized:
            if len(sequence) != len(seed_sequence):
                raise ValueError(
                    "Initial pool sequence length mismatch: "
                    f"{sequence!r}"
                )
            if not sequence or set(sequence) - canonical:
                raise ValueError(
                    f"Invalid amino-acid sequence in initial pool: {sequence!r}"
                )

        sequences = normalized
        seen = set(normalized)

        logger.info(
            "Shared initial pool injected | candidates=%d | "
            "proposal_operator_active=False",
            len(sequences),
        )

    else:
        max_proposal_batches = max(1, int(DIVERSITY_REFILL_ATTEMPTS))
        total_proposal_budget = population_size * max_proposal_batches
        proposal_budget_used = 0
        proposal_batches = 0

        while (
            len(sequences) < population_size
            and proposal_batches < max_proposal_batches
        ):
            missing = population_size - len(sequences)
            remaining_budget = total_proposal_budget - proposal_budget_used

            if remaining_budget <= 0:
                break

            # Preserve the original first-batch behavior.
            # Oversample only during duplicate-refill batches.
            if REMOVE_DUPLICATE_CANDIDATES and proposal_batches > 0:
                requested_size = min(missing * 4, remaining_budget)
            else:
                requested_size = min(missing, remaining_budget)

            if requested_size <= 0:
                break

            batch = generate_batch(requested_size)

            # Advance the proposal seed for the next batch.
            attempts += 1
            proposal_batches += 1
            proposal_budget_used += requested_size

            before = len(sequences)

            for sequence in batch:
                normalized = str(sequence).strip().upper()

                if not normalized:
                    continue

                if REMOVE_DUPLICATE_CANDIDATES:
                    if normalized in seen:
                        continue
                    seen.add(normalized)

                sequences.append(normalized)

                if len(sequences) >= population_size:
                    break

            logger.debug(
                "Population refill | batch=%d/%d | requested=%d | "
                "accepted=%d | total=%d/%d | proposal_budget=%d/%d",
                proposal_batches,
                max_proposal_batches,
                requested_size,
                len(sequences) - before,
                len(sequences),
                population_size,
                proposal_budget_used,
                total_proposal_budget,
            )

        if len(sequences) != population_size:
            raise RuntimeError(
                "POPULATION_PROPOSAL_EXHAUSTED: could not construct a "
                f"complete population. Expected {population_size}, "
                f"constructed {len(sequences)}; batches={proposal_batches}/"
                f"{max_proposal_batches}; proposals="
                f"{proposal_budget_used}/{total_proposal_budget}; "
                f"duplicate_removal={REMOVE_DUPLICATE_CANDIDATES}."
            )

        logger.info(
            "Population proposal fill complete | population=%d | "
            "batches=%d | proposals=%d/%d",
            population_size,
            proposal_batches,
            proposal_budget_used,
            total_proposal_budget,
        )

    # Preserve the requested elite, if applicable.
    preserved_elite = False

    if (
        initial_sequences is None
        and preserve_sequence
        and preserve_sequence.upper() not in sequences
        and sequences
    ):
        sequences[-1] = preserve_sequence.upper()
        preserved_elite = True

    # Evaluate candidates and attach mutation metadata.
    candidates: list[Candidate] = []
    evaluation_failures = 0

    controlled_budget = mutation_event_budget(
        len(seed_sequence),
        mutation_rate,
    )

    for sequence in sequences:
        sequence = sequence.upper()

        candidate = process_candidate_peptide(
            sequence,
            cache_enabled=cache_enabled,
        )

        if candidate is None:
            evaluation_failures += 1
            logger.warning(
                "Candidate processing returned None; generation will "
                "fail closed if the evaluation budget is not met."
            )
            continue

        if not isinstance(candidate.metadata, dict):
            candidate.metadata = {}

        candidate.metadata['initial_pool_injected'] = (
            initial_sequences is not None
        )
        candidate.metadata['proposal_operator_active'] = (
            initial_sequences is None
        )
        candidate.metadata['proposal_operator_used'] = (
            'shared_initial_pool'
            if initial_sequences is not None
            else mode
        )

        changed_positions = mutation_positions(seed_sequence, sequence)

        is_preserved = (
            preserved_elite
            and sequence == (preserve_sequence or "").upper()
        )

        if initial_sequences is not None or is_preserved:
            event_budget = 0
        elif mode in PAIRWISE_MODES:
            event_budget = len(changed_positions)
        elif mode in CONTROLLED_MODES:
            event_budget = controlled_budget
        else:
            event_budget = round(
                mutation_rate * len(seed_sequence)
            )

        candidate.metadata["changed_positions_count"] = len(
            changed_positions
        )
        candidate.metadata["mutation_event_budget"] = event_budget
        candidate.metadata["mutation_event_count"] = (
            0 if initial_sequences is not None else (
                len(changed_positions)
                if mode == "legacy" or mode in PAIRWISE_MODES
                else event_budget
            )
        )
        candidate.metadata["mutation_origin"] = (
            "pre_generated_shared_pool"
            if initial_sequences is not None
            else "evolutionary_proposal"
        )
        candidate.metadata["root_sequence_distance"] = len(changed_positions)
        candidate.metadata["mutations_proposed_this_generation"] = (
            0 if initial_sequences is not None else len(changed_positions)
        )

        candidate.metadata["mutation_count"] = (
            0 if initial_sequences is not None else len(changed_positions)
        )
        candidate.metadata["mutation_positions"] = changed_positions

        candidate.metadata["parent_sequence"] = seed_sequence
        candidate.metadata["run_id"] = run_id
        candidate.metadata["generation"] = generation

        candidate.metadata["mutation_guidance_mode"] = policy["mode"]
        candidate.metadata["requested_mutation_guidance_mode"] = (
            policy["requested_mode"]
        )
        candidate.metadata["hotspot_guided"] = (
            False if initial_sequences is not None else policy["guided"]
        )
        candidate.metadata["hotspot_probability"] = (
            policy["hotspot_probability"]
        )
        candidate.metadata["hotspot_positions_used"] = list(
            policy.get("hotspot_positions_used", [])
        )
        candidate.metadata["hotspot_weight_multiplier"] = policy.get(
            "hotspot_weight_multiplier", 1.0
        )
        candidate.metadata["hotspot_guidance_evidence_status"] = policy.get(
            "hotspot_guidance_evidence_status", "not_used"
        )
        candidate.metadata["hotspot_discovery_generation"] = (
            policy["hotspot_discovery_generation"]
        )
        candidate.metadata["hotspot_start"] = policy["hotspot_start"]
        candidate.metadata["hotspot_end"] = policy["hotspot_end"]

        candidate.metadata["is_duplicate"] = False
        candidate.metadata["preserved_elite"] = is_preserved

        # Never fabricate structural reward observations.
        candidate.metadata["mutation_reward_source"] = None
        candidate.metadata["mutation_parent_score"] = None
        candidate.metadata["mutation_child_score"] = None
        candidate.metadata["ranking_observation_valid"] = False

        candidates.append(candidate)

    unique_sequence_count = len({
        candidate.sequence for candidate in candidates
    })

    if len(candidates) != population_size:
        raise RuntimeError(
            "POPULATION_EVALUATION_UNDERFILL: refusing to return an "
            f"incomplete population. Expected {population_size}, "
            f"successfully evaluated {len(candidates)}; "
            f"candidate_processing_failures={evaluation_failures}."
        )

    if REMOVE_DUPLICATE_CANDIDATES and unique_sequence_count != population_size:
        raise RuntimeError(
            "POPULATION_DUPLICATES: duplicate sequences remain after "
            f"generation. Expected {population_size} unique candidates, "
            f"got {unique_sequence_count}."
        )

    logger.info(
        "Generated %d candidates (%d unique) | mode=%s | budget=%d",
        len(candidates),
        len({candidate.sequence for candidate in candidates}),
        mode,
        0 if initial_sequences is not None else controlled_budget,
    )

    return candidates 