"""Production target-aware scoring and reliability reporting.

This module does not generate docking poses or predict experimental affinity.
It evaluates sequence-matched, pre-generated receptor-peptide complexes.

Reliability remains diagnostic-only until externally calibrated.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from collections import defaultdict
from pathlib import Path
from typing import Any

from src.target_aware_scoring import (
    HotspotSpec,
    StructuralScoreConfig,
    score_peptide_receptor_complex,
)


TARGET_VERSION = "target_config_v3_generic"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalise_hotspots(raw: Any, receptor_chain: str) -> tuple[HotspotSpec, ...]:
    if not isinstance(raw, list) or not raw:
        raise ValueError("At least one target hotspot must be configured")

    result = []
    seen = set()

    for item in raw:
        if not isinstance(item, dict):
            raise ValueError("Every hotspot must be a JSON object")

        chain = str(item.get("chain", receptor_chain)).strip()
        residue_number = int(item["residue_number"])
        residue_name = str(item["residue_name"]).strip().upper()
        insertion_code = str(item.get("insertion_code", "")).strip()

        if not chain or not residue_name or residue_number <= 0:
            raise ValueError(f"Invalid hotspot definition: {item}")

        if chain != receptor_chain:
            raise ValueError(
                f"Hotspot chain {chain!r} does not match receptor chain "
                f"{receptor_chain!r}"
            )

        spec = HotspotSpec(
            chain=chain,
            residue_number=residue_number,
            residue_name=residue_name,
            insertion_code=insertion_code,
        )

        if spec.label() in seen:
            raise ValueError(f"Duplicate hotspot: {spec.label()}")

        seen.add(spec.label())
        result.append(spec)

    return tuple(result)


def _default_legacy_hotspots(target_id: str, receptor_chain: str) -> list[dict]:
    """Preserve the historical HERV-K configuration for old callers."""
    if target_id != "9SYA":
        return []

    return [
        {
            "chain": receptor_chain,
            "residue_number": 203,
            "residue_name": "ARG",
        },
        {
            "chain": receptor_chain,
            "residue_number": 205,
            "residue_name": "ARG",
        },
    ]


def _register_manifest(
    candidates: list[Any],
    manifest_path: str | Path,
) -> dict[str, Any]:
    path = Path(manifest_path).expanduser().resolve()

    if not path.is_file():
        raise FileNotFoundError(f"Target manifest not found: {path}")

    manifest = json.loads(path.read_text(encoding="utf-8"))

    if manifest.get("schema_version") != 1:
        raise ValueError("Unsupported target manifest schema_version")

    target = manifest.get("target")
    complexes = manifest.get("complexes")

    if not isinstance(target, dict) or not isinstance(complexes, list):
        raise ValueError("Manifest must contain target and complexes")

    target_id = str(target.get("target_structure_id", "")).strip()
    receptor_chain = str(target.get("receptor_chain", "")).strip()
    peptide_chain = str(target.get("peptide_chain", "")).strip()

    if not target_id or not receptor_chain or not peptide_chain:
        raise ValueError("Target ID and both chain IDs are required")

    if receptor_chain == peptide_chain:
        raise ValueError("Receptor and peptide chains must be different")

    hotspots = _normalise_hotspots(
        target.get("hotspots"),
        receptor_chain,
    )

    by_sequence: dict[str, list[dict[str, Any]]] = defaultdict(list)
    rejected = []

    for index, raw in enumerate(complexes):
        try:
            if not isinstance(raw, dict):
                raise ValueError("Complex record must be an object")

            sequence = str(raw.get("sequence", "")).strip().upper()
            raw_path = raw.get("path")
            expected_hash = str(raw.get("sha256", "")).lower()

            if not sequence or not raw_path:
                raise ValueError("Sequence and path are required")

            if len(sequence) < 2:
                raise ValueError("Invalid peptide sequence")

            if not expected_hash:
                raise ValueError("A SHA-256 hash is required")

            complex_path = Path(raw_path).expanduser()

            if not complex_path.is_absolute():
                complex_path = path.parent / complex_path

            complex_path = complex_path.resolve()

            if not complex_path.is_file():
                raise FileNotFoundError(complex_path)

            actual_hash = _sha256(complex_path)

            if actual_hash != expected_hash:
                raise ValueError(
                    f"SHA-256 mismatch for {complex_path.name}"
                )

            by_sequence[sequence].append({
                "path": str(complex_path),
                "sha256": actual_hash,
                "sequence": sequence,
                "target_structure_id": target_id,
                "receptor_chain": receptor_chain,
                "peptide_chain": peptide_chain,
                "hotspots": [
                    {
                        "chain": h.chain,
                        "residue_number": h.residue_number,
                        "residue_name": h.residue_name,
                        "insertion_code": h.insertion_code,
                    }
                    for h in hotspots
                ],
                "provenance": str(
                    raw.get("provenance", "manifest_registered_complex")
                ),
                "independent_run_id": raw.get("independent_run_id"),
                "random_seed": raw.get("random_seed"),
                "protocol_sha256": raw.get("protocol_sha256"),
            })

        except Exception as exc:
            rejected.append({
                "record_index": index,
                "error": f"{type(exc).__name__}: {exc}",
            })

    matched_records = 0
    matched_candidates = 0

    for candidate in candidates:
        sequence = str(candidate.sequence).upper()
        entries = by_sequence.get(sequence, [])

        candidate.metadata["target_structure_id"] = target_id
        candidate.metadata["target_receptor_chain"] = receptor_chain
        candidate.metadata["target_peptide_chain"] = peptide_chain
        candidate.metadata["target_hotspots"] = target["hotspots"]
        candidate.metadata["target_complexes"] = entries

        if entries:
            matched_candidates += 1
            matched_records += len(entries)

    return {
        "status": "loaded",
        "manifest_path": str(path),
        "target_structure_id": target_id,
        "candidate_count": len(candidates),
        "matched_candidate_count": matched_candidates,
        "matched_complex_count": matched_records,
        "unmatched_candidate_count": len(candidates) - matched_candidates,
        "rejected_manifest_records": rejected,
    }


def _interface_fingerprint(
    path: Path,
    receptor_chain: str,
    peptide_chain: str,
    cutoff_A: float = 5.0,
) -> set[str]:
    """Return unique receptor-peptide residue pairs within the cutoff."""
    import numpy as np

    from src.target_aware_scoring import _parse_pdb_atoms

    atoms = _parse_pdb_atoms(path, {receptor_chain, peptide_chain})

    receptor = [
        atom for atom in atoms
        if atom.chain == receptor_chain
        and atom.element.upper() not in {"H", "D"}
    ]
    peptide = [
        atom for atom in atoms
        if atom.chain == peptide_chain
        and atom.element.upper() not in {"H", "D"}
    ]

    if not receptor or not peptide:
        raise ValueError("Cannot build interface fingerprint from empty chains")

    rxyz = np.asarray([atom.xyz for atom in receptor], dtype=float)
    pxyz = np.asarray([atom.xyz for atom in peptide], dtype=float)

    distances_squared = np.sum(
        (rxyz[:, None, :] - pxyz[None, :, :]) ** 2,
        axis=2,
    )

    rows, cols = np.where(distances_squared <= cutoff_A ** 2)

    def residue_token(atom: Any) -> str:
        return (
            f"{atom.chain}:{atom.residue_number}"
            f"{atom.insertion_code or ''}:{atom.residue_name}"
        )

    return {
        f"{residue_token(receptor[i])}|{residue_token(peptide[j])}"
        for i, j in zip(rows, cols)
    }


def _reliability_diagnostic(
    complex_results: list[dict[str, Any]],
) -> dict[str, Any]:
    """Calculate an uncalibrated repeatability diagnostic.

    Requires at least two independent runs, at least two poses per run,
    unique random seeds, and the same protocol hash across runs.
    """
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for result in complex_results:
        run_id = result.get("independent_run_id")

        if run_id is not None and str(run_id).strip():
            groups[str(run_id)].append(result)

    if len(groups) < 2:
        return {
            "status": "insufficient_independent_runs",
            "independent_run_count": len(groups),
            "calibrated": False,
            "feedback_active": False,
            "reason": "At least two documented independent runs are required.",
        }

    for run_id, entries in groups.items():
        if len(entries) < 2:
            return {
                "status": "insufficient_poses_per_run",
                "independent_run_count": len(groups),
                "calibrated": False,
                "feedback_active": False,
                "reason": f"Run {run_id} has fewer than two poses.",
            }

    protocols = {
        str(result.get("protocol_sha256", ""))
        for result in complex_results
    }

    if len(protocols) != 1 or not next(iter(protocols)):
        return {
            "status": "protocol_mismatch_or_missing",
            "independent_run_count": len(groups),
            "calibrated": False,
            "feedback_active": False,
            "reason": "Independent runs must share a documented protocol hash.",
        }

    seeds = {}

    for run_id, entries in groups.items():
        run_seeds = {
            str(entry.get("random_seed"))
            for entry in entries
            if entry.get("random_seed") is not None
        }

        if len(run_seeds) != 1:
            return {
                "status": "invalid_run_seed_metadata",
                "independent_run_count": len(groups),
                "calibrated": False,
                "feedback_active": False,
                "reason": f"Run {run_id} lacks one consistent random seed.",
            }

        seeds[run_id] = next(iter(run_seeds))

    if len(set(seeds.values())) != len(seeds):
        return {
            "status": "nonindependent_seed_metadata",
            "independent_run_count": len(groups),
            "calibrated": False,
            "feedback_active": False,
            "reason": "Independent run IDs must use distinct random seeds.",
        }

    runs = []

    for run_id in sorted(groups):
        fingerprints = []

        for entry in groups[run_id]:
            fingerprint = entry.get("_interface_fingerprint_5A")

            if not fingerprint:
                return {
                    "status": "missing_interface_fingerprint",
                    "independent_run_count": len(groups),
                    "calibrated": False,
                    "feedback_active": False,
                    "reason": f"Run {run_id} contains an empty fingerprint.",
                }

            fingerprints.append(set(fingerprint))

        runs.append(fingerprints)

    try:
        from prototype4.p4_closed_loop import cross_run_reliability

        result = cross_run_reliability(runs)

    except Exception as exc:
        return {
            "status": "calculation_failed",
            "independent_run_count": len(groups),
            "calibrated": False,
            "feedback_active": False,
            "reason": f"{type(exc).__name__}: {exc}",
        }

    result.update({
        "status": "diagnostic_only",
        "n_independent_runs": len(groups),
        "random_seeds": seeds,
        "protocol_sha256": next(iter(protocols)),
        "calibrated": False,
        "feedback_active": False,
        "interpretation": (
            "Interface repeatability diagnostic only. "
            "Not experimental binding probability or structural accuracy."
        ),
    })

    return result


def _score_complex(
    candidate: Any,
    entry: dict[str, Any],
) -> dict[str, Any]:
    path = Path(entry["path"]).expanduser().resolve()

    if not path.is_file():
        raise FileNotFoundError(path)

    expected_hash = entry.get("sha256")

    if expected_hash and _sha256(path) != str(expected_hash).lower():
        raise ValueError("Complex SHA-256 changed after manifest registration")

    target_id = str(entry.get("target_structure_id", "")).strip()
    receptor_chain = str(entry.get("receptor_chain", "A")).strip()
    peptide_chain = str(entry.get("peptide_chain", "B")).strip()

    if not target_id:
        raise ValueError("Target structure ID is missing")

    hotspots_raw = entry.get("hotspots")

    if not hotspots_raw:
        hotspots_raw = _default_legacy_hotspots(
            target_id,
            receptor_chain,
        )

    hotspots = _normalise_hotspots(hotspots_raw, receptor_chain)

    config = StructuralScoreConfig(
        hotspot_residues=hotspots,
    )

    result = score_peptide_receptor_complex(
        path,
        config=config,
        receptor_chain=receptor_chain,
        peptide_chain=peptide_chain,
        target_structure_id=target_id,
        structure_provenance=str(
            entry.get("provenance", "manifest_complex")
        ),
    )

    actual_sequence = str(result.get("peptide_sequence", "")).upper()

    if actual_sequence != str(candidate.sequence).upper():
        raise ValueError(
            "Candidate/complex sequence mismatch: "
            f"{candidate.sequence} != {actual_sequence}"
        )

    if result.get("score_valid") is not True:
        raise ValueError(
            "Structural validation failed: "
            + ";".join(result.get("eligibility_reasons", []))
        )

    metrics = result.get("structural_metrics", {})
    hotspot_rows = metrics.get("hotspot_metrics", [])

    observed = {
        row.get("hotspot"): float(row["minimum_distance_A"])
        for row in hotspot_rows
        if row.get("minimum_distance_A") is not None
    }

    required_labels = {hotspot.label() for hotspot in hotspots}
    missing = required_labels - set(observed)

    if missing:
        raise ValueError(
            "Missing configured hotspot measurements: "
            + ", ".join(sorted(missing))
        )

    hotspot_distances = {
        label: observed[label]
        for label in sorted(required_labels)
    }

    proximity = sum(
        math.exp(-max(distance - 4.0, 0.0) / 2.0)
        for distance in hotspot_distances.values()
    ) / len(hotspot_distances)

    score = float(result["target_aware_structural_score"])

    if not math.isfinite(score):
        raise ValueError("Structural score is not finite")

    try:
        fingerprint = _interface_fingerprint(
            path,
            receptor_chain,
            peptide_chain,
            cutoff_A=5.0,
        )
        fingerprint_error = None
    except Exception as exc:
        fingerprint = set()
        fingerprint_error = f"{type(exc).__name__}: {exc}"

    output = {
        "path": str(path),
        "target_structure_id": target_id,
        "score_version": result.get("score_version"),
        "complex_sha256": result.get(
            "structure_provenance", {}
        ).get("sha256"),
        "target_geometry_score": score,
        "hotspot_distances_A": hotspot_distances,
        "hotspot_proximity_score": proximity,
        "minimum_interchain_distance_A": metrics.get(
            "minimum_interchain_heavy_atom_distance_A"
        ),
        "severe_clash_count": metrics.get(
            "severe_clash_heavy_atom_pairs"
        ),
        "interface_residue_pairs_5A": metrics.get(
            "distinct_interchain_residue_pairs", {}
        ).get("5A"),
        "independent_run_id": entry.get("independent_run_id"),
        "random_seed": entry.get("random_seed"),
        "protocol_sha256": entry.get("protocol_sha256"),
        "_interface_fingerprint_5A": sorted(fingerprint),
        "fingerprint_error": fingerprint_error,
    }

    # Preserve compatibility with historical HERV-K reports.
    for label, distance in hotspot_distances.items():
        if label.endswith(":203:ARG"):
            output["arg203_min_A"] = distance
        elif label.endswith(":205:ARG"):
            output["arg205_min_A"] = distance

    return output


def _pareto_fronts(
    objectives: list[tuple[float, ...]],
) -> list[int]:
    remaining = set(range(len(objectives)))
    ranks = [-1] * len(objectives)
    rank = 0

    while remaining:
        front = []

        for i in sorted(remaining):
            dominated = False

            for j in remaining:
                if i == j:
                    continue

                a, b = objectives[j], objectives[i]

                if all(x >= y for x, y in zip(a, b)) and any(
                    x > y for x, y in zip(a, b)
                ):
                    dominated = True
                    break

            if not dominated:
                front.append(i)

        if not front:
            raise RuntimeError("Pareto front construction failed")

        for i in front:
            ranks[i] = rank
            remaining.remove(i)

        rank += 1

    return ranks



def _summarize_distribution(values: list[float]) -> dict[str, Any]:
    """Summarize variation across scored poses without calling them replicates."""
    ordered = sorted(float(value) for value in values)

    if not ordered:
        raise ValueError("Cannot summarize an empty pose distribution")

    n = len(ordered)
    middle = n // 2

    if n % 2:
        median = ordered[middle]
    else:
        median = (ordered[middle - 1] + ordered[middle]) / 2.0

    return {
        "count": n,
        "mean": sum(ordered) / n,
        "median": median,
        "minimum": ordered[0],
        "maximum": ordered[-1],
    }


def _summarize_pose_source_groups(
    complex_results: list[dict[str, Any]],
) -> dict[str, Any]:
    """Summarize pose metrics by source directory.

    Directory labels are descriptive file-origin strata only.
    They are not independent runs, experimental replicates,
    or evidence of structural accuracy.
    """
    grouped: dict[str, list[dict[str, Any]]] = {}

    for item in complex_results:
        raw_path = item.get("path")
        group = (
            Path(str(raw_path)).parent.name
            if raw_path else "unknown_source"
        )
        group = group or "unknown_source"
        grouped.setdefault(group, []).append(item)

    def metric_summary(
        poses: list[dict[str, Any]],
        key: str,
    ) -> dict[str, Any] | None:
        values = []

        for pose in poses:
            try:
                value = float(pose.get(key))
            except (TypeError, ValueError):
                continue

            if math.isfinite(value):
                values.append(value)

        return _summarize_distribution(values) if values else None

    summaries = []

    for group, poses in sorted(grouped.items()):
        hotspot_labels = sorted({
            label
            for pose in poses
            for label in (pose.get("hotspot_distances_A") or {})
        })

        hotspot_summaries = {}

        for label in hotspot_labels:
            values = []

            for pose in poses:
                distances = pose.get("hotspot_distances_A") or {}

                if label not in distances:
                    continue

                try:
                    value = float(distances[label])
                except (TypeError, ValueError):
                    continue

                if math.isfinite(value):
                    values.append(value)

            hotspot_summaries[label] = (
                _summarize_distribution(values) if values else None
            )

        summaries.append({
            "source_group": group,
            "pose_count": len(poses),
            "target_geometry_score": metric_summary(
                poses, "target_geometry_score"
            ),
            "hotspot_proximity_score": metric_summary(
                poses, "hotspot_proximity_score"
            ),
            "interface_residue_pairs_5A": metric_summary(
                poses, "interface_residue_pairs_5A"
            ),
            "minimum_interchain_distance_A": metric_summary(
                poses, "minimum_interchain_distance_A"
            ),
            "hotspot_distance_summaries_A": hotspot_summaries,
        })

    return {
        "grouping_basis": "pose_file_parent_directory_name",
        "independence_claimed": False,
        "interpretation": (
            "Descriptive file-origin grouping only. "
            "These groups are not independent runs, experimental "
            "replicates, or structural-accuracy validation."
        ),
        "group_count": len(summaries),
        "groups": summaries,
    }


def apply_p4_target_objective(
    candidates: list[Any],
    *,
    generation: int,
    output_directory: str | Path,
    pareto_enabled: bool | None = None,
) -> tuple[list[Any], dict[str, Any]]:
    """Score registered complexes, report reliability, optionally reorder."""

    manifest_report = {
        "status": "not_configured",
        "matched_candidate_count": 0,
        "matched_complex_count": 0,
    }

    manifest_path = os.environ.get(
        "SILICON_VIROVORE_P4_TARGET_MANIFEST"
    )

    if manifest_path:
        manifest_report = _register_manifest(candidates, manifest_path)

    if pareto_enabled is None:
        pareto_enabled = (
            os.environ.get(
                "SILICON_VIROVORE_P4_TARGET_PARETO", "1"
            ) == "1"
        )

    records = []
    eligible = []
    reliability_count = 0

    for candidate in candidates:
        meta = candidate.metadata
        raw_entries = meta.get("target_complexes")

        if raw_entries is None:
            raw_path = meta.get("target_complex_path")
            raw_entries = [{"path": raw_path}] if raw_path else []

        if isinstance(raw_entries, dict):
            raw_entries = [raw_entries]

        entry_results = []
        errors = []

        for raw in raw_entries:
            try:
                if isinstance(raw, str):
                    raw = {"path": raw}

                target_id = raw.get(
                    "target_structure_id",
                    meta.get("target_structure_id", "9SYA"),
                )

                receptor_chain = raw.get(
                    "receptor_chain",
                    meta.get("target_receptor_chain", "A"),
                )

                peptide_chain = raw.get(
                    "peptide_chain",
                    meta.get("target_peptide_chain", "B"),
                )

                hotspots = raw.get(
                    "hotspots",
                    meta.get("target_hotspots"),
                )

                if not hotspots:
                    hotspots = _default_legacy_hotspots(
                        str(target_id),
                        str(receptor_chain),
                    )

                entry = {
                    "path": raw["path"],
                    "sha256": raw.get("sha256"),
                    "target_structure_id": target_id,
                    "receptor_chain": receptor_chain,
                    "peptide_chain": peptide_chain,
                    "hotspots": hotspots,
                    "provenance": raw.get(
                        "provenance",
                        meta.get(
                            "target_complex_provenance",
                            "external_complex",
                        ),
                    ),
                    "independent_run_id": raw.get("independent_run_id"),
                    "random_seed": raw.get("random_seed"),
                    "protocol_sha256": raw.get("protocol_sha256"),
                }

                entry_results.append(_score_complex(candidate, entry))

            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")

        if entry_results and not errors:
            hotspot_labels = sorted(
                set.intersection(*[
                    set(item["hotspot_distances_A"])
                    for item in entry_results
                ])
            )

            if not hotspot_labels:
                errors.append("No common configured hotspots across complexes")

        if entry_results and not errors:
            geometry = sum(
                item["target_geometry_score"] for item in entry_results
            ) / len(entry_results)

            mean_hotspots = {
                label: sum(
                    item["hotspot_distances_A"][label]
                    for item in entry_results
                ) / len(entry_results)
                for label in hotspot_labels
            }

            proximity = sum(
                item["hotspot_proximity_score"]
                for item in entry_results
            ) / len(entry_results)

            reliability = _reliability_diagnostic(entry_results)

            meta["p4_target_evidence"] = {
                "version": TARGET_VERSION,
                "status": "success",
                "target_structure_id": entry_results[0]["target_structure_id"],
                "pose_count": len(entry_results),
                "target_geometry_score_mean": geometry,
                "target_geometry_score_summary": _summarize_distribution([
                    item["target_geometry_score"]
                    for item in entry_results
                ]),
                "hotspot_distances_A_mean": mean_hotspots,
                "hotspot_distance_summaries_A": {
                    label: _summarize_distribution([
                        item["hotspot_distances_A"][label]
                        for item in entry_results
                    ])
                    for label in hotspot_labels
                },
                "hotspot_proximity_score": proximity,
                "hotspot_proximity_score_summary": _summarize_distribution([
                    item["hotspot_proximity_score"]
                    for item in entry_results
                ]),
                "arg203_min_A_mean": mean_hotspots.get(
                    "A:203:ARG"
                ),
                "arg205_min_A_mean": mean_hotspots.get(
                    "A:205:ARG"
                ),
                "reliability_calibrated": False,
                "pose_source_groups": _summarize_pose_source_groups(
                    entry_results
                ),
                "complex_results": [
                    {
                        key: value
                        for key, value in item.items()
                        if key != "_interface_fingerprint_5A"
                    }
                    for item in entry_results
                ],
            }

            meta["p4_reliability"] = reliability

            if reliability.get("status") == "diagnostic_only":
                reliability_count += 1

            eligible.append(candidate)

        else:
            status = (
                "missing_complex"
                if not raw_entries
                else "invalid_complex"
            )

            meta["p4_target_evidence"] = {
                "version": TARGET_VERSION,
                "status": status,
                "errors": errors,
                "reliability_calibrated": False,
            }

            meta["p4_reliability"] = {
                "status": "unavailable_without_valid_target_evidence",
                "calibrated": False,
                "feedback_active": False,
            }

        records.append({
            "sequence": candidate.sequence,
            "candidate_id": meta.get("candidate_id"),
            **meta["p4_target_evidence"],
            "reliability": meta["p4_reliability"],
        })

    coverage = len(eligible) / len(candidates) if candidates else 0.0

    reordered = False
    reason = "Target evidence recorded; legacy ranking retained."

    if pareto_enabled:
        scores_valid = all(
            getattr(candidate, "c_score", None) is not None
            and math.isfinite(float(candidate.c_score))
            for candidate in candidates
        )

        if candidates and len(eligible) == len(candidates) and scores_valid:
            objectives = []

            for candidate in candidates:
                target = candidate.metadata["p4_target_evidence"]

                fitness = max(
                    0.0,
                    min(1.0, float(candidate.c_score)),
                )

                objectives.append((
                    fitness,
                    float(target["target_geometry_score_mean"]),
                    float(target["hotspot_proximity_score"]),
                ))

            fronts = _pareto_fronts(objectives)
            original_order = {
                id(candidate): index
                for index, candidate in enumerate(candidates)
            }

            for candidate, front in zip(candidates, fronts):
                candidate.metadata["p4_target_pareto_front"] = front

            candidates = sorted(
                candidates,
                key=lambda candidate: (
                    candidate.metadata["p4_target_pareto_front"],
                    -float(candidate.overall_score),
                    original_order[id(candidate)],
                ),
            )

            for rank, candidate in enumerate(candidates, start=1):
                candidate.rank = rank

            reordered = True
            reason = (
                "All candidates have valid target evidence and finite "
                "sequence scores; Pareto selection applied."
            )

        elif len(eligible) != len(candidates):
            reason = (
                "Pareto selection withheld: complete valid target "
                "evidence is required for every candidate."
            )
        else:
            reason = (
                "Pareto selection withheld: every candidate requires "
                "a finite sequence-level c_score."
            )

    report = {
        "generation": generation,
        "version": TARGET_VERSION,
        "candidate_count": len(candidates),
        "target_evidence_count": len(eligible),
        "target_evidence_coverage": coverage,
        "pareto_requested": bool(pareto_enabled),
        "pareto_reordered_candidates": reordered,
        "reason": reason,
        "manifest": manifest_report,
        "reliability_diagnostic_candidate_count": reliability_count,
        "reliability_feedback_active": False,
        "reliability_calibrated": False,
        "legacy_fitness_scores_modified": False,
        "candidates": records,
    }

    out = Path(output_directory) / "p4_target_evidence"
    out.mkdir(parents=True, exist_ok=True)

    report_path = out / f"generation_{generation:04d}.json"
    report_path.write_text(
        json.dumps(report, indent=2, default=str) + "\n",
        encoding="utf-8",
    )

    report["report_path"] = str(report_path)

    return candidates, report
