import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

import src.p4_pipeline_integration as p4


def make_candidate(sequence):
    return SimpleNamespace(
        sequence=sequence,
        metadata={},
        c_score=0.5,
        overall_score=0.5,
        rank=0,
    )


def write_manifest(tmp_path, sequence, *, expected_hash=None):
    pose = tmp_path / "pose.pdb"
    pose.write_text("TEST STRUCTURE\n")

    actual_hash = hashlib.sha256(pose.read_bytes()).hexdigest()

    manifest = {
        "schema_version": 1,
        "target": {
            "target_structure_id": "TEST_TARGET",
            "receptor_chain": "R",
            "peptide_chain": "P",
            "hotspots": [
                {
                    "chain": "R",
                    "residue_number": 42,
                    "residue_name": "GLU",
                }
            ],
        },
        "complexes": [
            {
                "sequence": sequence,
                "path": pose.name,
                "sha256": expected_hash or actual_hash,
                "provenance": "test_fixture",
            }
        ],
    }

    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(manifest))
    return path, pose, actual_hash


def test_generic_hotspot_configuration():
    hotspots = p4._normalise_hotspots(
        [
            {
                "chain": "R",
                "residue_number": 42,
                "residue_name": "GLU",
            },
            {
                "chain": "R",
                "residue_number": 51,
                "residue_name": "ASP",
            },
        ],
        "R",
    )

    assert len(hotspots) == 2
    assert hotspots[0].label() == "R:42:GLU"
    assert hotspots[1].label() == "R:51:ASP"


def test_duplicate_hotspots_are_rejected():
    with pytest.raises(ValueError, match="Duplicate hotspot"):
        p4._normalise_hotspots(
            [
                {"chain": "R", "residue_number": 42,
                 "residue_name": "GLU"},
                {"chain": "R", "residue_number": 42,
                 "residue_name": "GLU"},
            ],
            "R",
        )


def test_manifest_matches_exact_candidate_sequence(tmp_path):
    sequence = "ACDEFGHIK"
    manifest, pose, digest = write_manifest(tmp_path, sequence)

    matching = make_candidate(sequence)
    unmatched = make_candidate("ACDEFGHIL")

    report = p4._register_manifest(
        [matching, unmatched],
        manifest,
    )

    assert report["matched_candidate_count"] == 1
    assert report["matched_complex_count"] == 1
    assert matching.metadata["target_complexes"][0]["sha256"] == digest
    assert Path(matching.metadata["target_complexes"][0]["path"]) == pose
    assert unmatched.metadata["target_complexes"] == []


def test_manifest_rejects_incorrect_sha256(tmp_path):
    sequence = "ACDEFGHIK"
    manifest, _, _ = write_manifest(
        tmp_path,
        sequence,
        expected_hash="0" * 64,
    )

    candidate = make_candidate(sequence)
    report = p4._register_manifest([candidate], manifest)

    assert report["matched_candidate_count"] == 0
    assert candidate.metadata["target_complexes"] == []
    assert len(report["rejected_manifest_records"]) == 1
    assert "SHA-256 mismatch" in (
        report["rejected_manifest_records"][0]["error"]
    )


def test_reliability_requires_independent_runs():
    entries = [
        {
            "independent_run_id": "run_1",
            "random_seed": 101,
            "protocol_sha256": "protocol_hash",
            "_interface_fingerprint_5A": ["A"],
        },
        {
            "independent_run_id": "run_1",
            "random_seed": 101,
            "protocol_sha256": "protocol_hash",
            "_interface_fingerprint_5A": ["A"],
        },
    ]

    result = p4._reliability_diagnostic(entries)

    assert result["status"] == "insufficient_independent_runs"
    assert result["calibrated"] is False
    assert result["feedback_active"] is False


def test_reliability_diagnostic_remains_uncalibrated(monkeypatch):
    def fake_cross_run_reliability(runs):
        assert len(runs) == 2
        assert all(len(run) == 2 for run in runs)
        return {
            "reliability_proxy": 0.8,
            "mean_cross_run_jaccard_similarity": 0.9,
        }

    monkeypatch.setattr(
        "prototype4.p4_closed_loop.cross_run_reliability",
        fake_cross_run_reliability,
    )

    entries = []

    for run_id, seed in (("run_1", 101), ("run_2", 202)):
        for pose_index in range(2):
            entries.append({
                "independent_run_id": run_id,
                "random_seed": seed,
                "protocol_sha256": "same_protocol",
                "_interface_fingerprint_5A": [
                    f"R:{pose_index}:GLU|P:1:ALA"
                ],
            })

    result = p4._reliability_diagnostic(entries)

    assert result["status"] == "diagnostic_only"
    assert result["calibrated"] is False
    assert result["feedback_active"] is False
    assert result["n_independent_runs"] == 2


def test_missing_target_evidence_is_reported_and_not_ranked(tmp_path, monkeypatch):
    monkeypatch.delenv(
        "SILICON_VIROVORE_P4_TARGET_MANIFEST",
        raising=False,
    )
    monkeypatch.delenv(
        "SILICON_VIROVORE_P4_TARGET_PARETO",
        raising=False,
    )

    candidate = make_candidate("ACDEFGHIK")

    ranked, report = p4.apply_p4_target_objective(
        [candidate],
        generation=1,
        output_directory=tmp_path,
        pareto_enabled=True,
    )

    assert report["target_evidence_coverage"] == 0.0
    assert report["pareto_reordered_candidates"] is False
    assert candidate.metadata["p4_target_evidence"]["status"] == (
        "missing_complex"
    )
    assert Path(report["report_path"]).is_file()
    assert ranked == [candidate]


def _write_pipeline_test_complex(tmp_path):
    """Create a valid, controlled ALA-receptor / GLY-peptide complex."""
    def atom(serial, residue, chain, residue_number, x, y, z):
        return (
            f"ATOM  {serial:5d} {'CA':4s} {residue:>3s} "
            f"{chain}{residue_number:4d}    "
            f"{x:8.3f}{y:8.3f}{z:8.3f}"
            f"{1.00:6.2f}{20.00:6.2f}          {'C':>2s}\n"
        )

    lines = []
    positions = (
        (0, 0, 0),
        (0, 10, 0),
        (0, 0, 10),
    )

    serial = 1

    for residue_number, (x, y, z) in enumerate(positions, 1):
        lines.append(
            atom(serial, "ALA", "A", residue_number, x, y, z)
        )
        serial += 1

    for residue_number, (x, y, z) in enumerate(positions, 1):
        lines.append(
            atom(serial, "GLY", "B", residue_number, x + 3, y, z)
        )
        serial += 1

    lines.append("END\n")

    path = tmp_path / "candidate_complex.pdb"
    path.write_text("".join(lines), encoding="utf-8")
    return path


def _write_pipeline_manifest(tmp_path, pose, hotspot, target_id):
    digest = hashlib.sha256(pose.read_bytes()).hexdigest()

    manifest = {
        "schema_version": 1,
        "target": {
            "target_structure_id": target_id,
            "receptor_chain": "A",
            "peptide_chain": "B",
            "hotspots": [hotspot],
        },
        "complexes": [
            {
                "sequence": "GGG",
                "path": pose.name,
                "sha256": digest,
                "provenance": "controlled_integration_test",
            }
        ],
    }

    path = tmp_path / "target_manifest.json"
    path.write_text(json.dumps(manifest), encoding="utf-8")
    return path


def test_end_to_end_custom_target_scoring_and_pareto(tmp_path, monkeypatch):
    pose = _write_pipeline_test_complex(tmp_path)

    manifest = _write_pipeline_manifest(
        tmp_path,
        pose,
        {
            "chain": "A",
            "residue_number": 1,
            "residue_name": "ALA",
        },
        "SYNTHETIC_TARGET_1",
    )

    monkeypatch.setenv(
        "SILICON_VIROVORE_P4_TARGET_MANIFEST",
        str(manifest),
    )

    candidate = make_candidate("GGG")

    ranked, report = p4.apply_p4_target_objective(
        [candidate],
        generation=1,
        output_directory=tmp_path / "run",
        pareto_enabled=True,
    )

    evidence = candidate.metadata["p4_target_evidence"]

    assert report["manifest"]["matched_candidate_count"] == 1
    assert report["target_evidence_coverage"] == 1.0
    assert report["pareto_reordered_candidates"] is True

    assert evidence["status"] == "success"
    assert evidence["target_structure_id"] == "SYNTHETIC_TARGET_1"
    assert evidence["pose_count"] == 1

    assert evidence["target_geometry_score_mean"] >= 0.0
    assert evidence["target_geometry_score_summary"]["count"] == 1
    assert evidence["hotspot_distance_summaries_A"]["A:1:ALA"]["count"] == 1
    assert evidence["hotspot_distances_A_mean"]["A:1:ALA"] == pytest.approx(
        3.0, abs=0.01
    )

    assert candidate.metadata["p4_reliability"]["status"] == (
        "insufficient_independent_runs"
    )
    assert candidate.metadata["p4_reliability"]["calibrated"] is False
    assert ranked == [candidate]

    report_path = Path(report["report_path"])
    assert report_path.is_file()


def test_target_switch_uses_new_hotspot_definition(tmp_path, monkeypatch):
    pose = _write_pipeline_test_complex(tmp_path)

    manifest = _write_pipeline_manifest(
        tmp_path,
        pose,
        {
            "chain": "A",
            "residue_number": 2,
            "residue_name": "ALA",
        },
        "SYNTHETIC_TARGET_2",
    )

    monkeypatch.setenv(
        "SILICON_VIROVORE_P4_TARGET_MANIFEST",
        str(manifest),
    )

    candidate = make_candidate("GGG")

    _, report = p4.apply_p4_target_objective(
        [candidate],
        generation=1,
        output_directory=tmp_path / "run",
        pareto_enabled=False,
    )

    evidence = candidate.metadata["p4_target_evidence"]

    assert report["target_evidence_coverage"] == 1.0
    assert evidence["status"] == "success"
    assert evidence["target_structure_id"] == "SYNTHETIC_TARGET_2"

    distances = evidence["hotspot_distances_A_mean"]

    assert set(distances) == {"A:2:ALA"}
    assert distances["A:2:ALA"] == pytest.approx(3.0, abs=0.01)
