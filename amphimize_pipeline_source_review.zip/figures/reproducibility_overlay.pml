
reinitialize

load "/Users/centurion616/Desktop/Silicon-Virovore/prototype4/results/p4_visualization_20261103/seed1917_rank1.pdb", run1917
load "/Users/centurion616/Desktop/Silicon-Virovore/prototype4/results/p4_visualization_20261103/seed2917_rank1.pdb", run2917

# Align both receptor structures, retaining their peptide coordinates.
align run2917 and chain A and name CA, run1917 and chain A and name CA

hide everything

# Use one aligned receptor as the background.
show cartoon, run1917 and chain A
show surface, run1917 and chain A
color gray80, run1917 and chain A
set transparency, 0.70, run1917 and chain A

# Contrasting peptide predictions.
show cartoon, run1917 and chain B
color cyan, run1917 and chain B

show cartoon, run2917 and chain B
color magenta, run2917 and chain B

# Target residues on the reference receptor.
select arg203, run1917 and chain A and resi 203 and resn ARG
select arg205, run1917 and chain A and resi 205 and resn ARG

show sticks, arg203 or arg205
color red, arg203
color orange, arg205
set stick_radius, 0.25, arg203 or arg205

label arg203 and name CZ, "Arg203"
label arg205 and name CZ, "Arg205"
set label_size, 25
set label_color, black
set label_outline_color, white

bg_color white
set orthoscopic, 1
set ray_shadows, 0
set antialias, 2
set two_sided_lighting, 1

orient (run1917 and chain A) or (run1917 and chain B) or (run2917 and chain B)
zoom (run1917 and chain A) or (run1917 and chain B) or (run2917 and chain B), 8

png /Users/centurion616/Desktop/Silicon-Virovore/prototype4/results/p4_visualization_20261103/reproducibility_overlay.png, 2600, 1900, dpi=300, ray=1
save /Users/centurion616/Desktop/Silicon-Virovore/prototype4/results/p4_visualization_20261103/reproducibility_overlay.pse
