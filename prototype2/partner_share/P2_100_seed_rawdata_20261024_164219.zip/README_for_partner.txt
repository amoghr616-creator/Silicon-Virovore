P2 100-SEED COMPARISON — RAW DATA PACKAGE

Primary experiment:
/Users/centurion616/Desktop/Silicon-Virovore/prototype2/p2_uniform_random_reset_vs_v2_100_20261023

Purpose:
Provide source records for graphing and independent analysis of the adaptive_substitution
versus uniform_baseline 100-seed comparison.

Primary file:
raw_100_seed_comparison/run_summary.csv

Summary schema:
seed, method, cli_mode, best_across_generations, generation10_best, mean_mutation_count, mean_pairwise_identity, run_id, log_file

Rows in run_summary.csv: 200
Distinct seed values detected: 100
Methods detected: adaptive_substitution, uniform_baseline

The experiment directory's nested CSV/JSON/log/text/metadata files are retained under
raw_100_seed_comparison/ with their original relative paths.

Previously reported summary statistics are provided separately in
reported_summary_metrics.csv. They are included as a reference, not as a replacement
for recalculating statistics from per-seed data. Verify the bootstrap interval's nominal
confidence level from the original analysis script before publication.

Important scientific interpretation:
- The primary score is a sequence-level fitness objective, not validated target-aware
  binding affinity or experimental activity.
- Use the seed-level run as the statistical unit; do not treat all candidate rows as
  independent replicates.
- The pooled unique-sequence figures are descriptive. Compute within-run and
  generation-level diversity before claiming a general diversity advantage.
- The uniform_baseline history contains only 399 globally unique sequences across 16000
  rows. Investigate this repetition pattern as a potential methodological or export issue.
- The subsequent 9SYA and 1YCR docking audits are included separately in
  supplemental_structural_validation/. They are not outcomes of the primary 100-seed
  sequence-fitness comparison, and they have not established structural binding success.

Reproducibility scripts:
reproducibility_sources/ contains relevant project scripts when those files were found.

Supplemental structural data:
supplemental_structural_validation/ contains selected candidate metadata and saved
geometry-audit summaries where available. Large coordinate files and model weights are
intentionally excluded.

Number of raw experiment data files collected: 1204
Source scripts included: 9
Supplemental structural files included: 12

Review this archive before forwarding it. It contains project logs and metadata; do not
include credentials, session cookies, or private account information.
