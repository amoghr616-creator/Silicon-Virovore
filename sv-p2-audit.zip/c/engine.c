// engine.c
// Silicon Virovore Biophysics Engine — Computational Core Utilities
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "virovore.h" 

// Flat array layout tracking absolute charge values per ASCII character
int amino_acid_charge[256] = {
    ['A'] = 0,  ['B'] = 0,  ['C'] = 0,  ['D'] = -1, ['E'] = -1,
    ['F'] = 0,  ['G'] = 0,  ['H'] = 0,  ['I'] = 0,  ['J'] = 0,
    ['K'] = 1,  ['L'] = 0,  ['M'] = 0,  ['N'] = 0,  ['O'] = 0,
    ['P'] = 0,  ['Q'] = 0,  ['R'] = 1,  ['S'] = 0,  ['T'] = 0,
    ['U'] = 0,  ['V'] = 0,  ['W'] = 0,  ['X'] = 0,  ['Y'] = 0, ['Z'] = 0
};

/**
 * Mathematically corrected threshold-step logic.
 * Safely ignores charges within bounds and scales exponentially for toxic over-charging.
 */
float calculate_charge_penalty(int net_charge, int threshold)
{
    int abs_charge = (net_charge < 0) ? -net_charge : net_charge;
    
    // Safely within bounds = zero penalty
    if (abs_charge <= threshold)
    {
        return 0.0f; 
    }
    else
    {
        // Linearly scale up the penalty magnitude for toxic hyper-charging
        return (float)((abs_charge - threshold) * 5.0f);
    }
}

static int is_standard_amino_acid(char aa)
{
    return strchr("ACDEFGHIKLMNPQRSTVWY", aa) != NULL;
}

int compute_charge_profile(const char *sequence, int charge_threshold, charge_summary *summary_out)
{
    if (sequence == NULL || summary_out == NULL)
    {
        fprintf(stderr, "ERROR: NULL pointer in compute_charge_profile\n");
        return -1;
    }
    
    int num_positive = 0;
    int num_negative = 0;
    size_t len = strlen(sequence);
    double max_patch = 0.0;
    
    // Window-based Localized Charge Density Tracking (Debye-Hückel precursor matrix)
    int window_size = 6;
    if (len >= (size_t)window_size) {
        for (size_t i = 0; i <= len - window_size; i++) {
            int local_charge = 0;
            for (int j = 0; j < window_size; j++) {
                char local_aa = toupper((unsigned char)sequence[i + j]);
                if (local_aa == 'K' || local_aa == 'R') local_charge++;
                if (local_aa == 'D' || local_aa == 'E') local_charge--;
            }
            double current_density = abs(local_charge) / (double)window_size;            
            if (current_density > max_patch) {
                max_patch = current_density;
            }
        }
    }
    
    for (size_t i = 0; i < len; i++) {
    char aa = (char)toupper((unsigned char)sequence[i]);

    if (!is_standard_amino_acid(aa)) {
        fprintf(
            stderr,
            "ERROR: Invalid amino acid '%c' at position %zu\n",
            sequence[i],
            i
        );
        return -1;
    }

    if (aa == 'K' || aa == 'R') {
        num_positive++;
    } else if (aa == 'D' || aa == 'E') {
        num_negative++;
    }
}
    
    summary_out->num_positive = num_positive;
    summary_out->num_negative = num_negative;
    summary_out->net_charge = num_positive - num_negative;
    summary_out->penalty = calculate_charge_penalty(summary_out->net_charge, charge_threshold);
    summary_out->max_patch_density = max_patch;

    return 0;  
}

// Chou-Fasman alpha-helix propensity lookup table
double get_chou_fasman_score(char aa) {
    switch (toupper((unsigned char)aa)) {
        case 'E': case 'A': case 'L': return 1.42; 
        case 'H': case 'M': case 'Q': case 'W': case 'V': case 'F': return 1.10;
        case 'K': case 'I': return 1.00; 
        case 'D': case 'T': case 'S': case 'R': case 'C': return 0.80; 
        case 'N': case 'Y': return 0.60; 
        case 'G': case 'P': return 0.50; 
        default: return 0.00;
    }
}

double calculate_chou_fasman(const char *sequence) {
    if (!sequence || *sequence == '\0') return 0.0;
    
    double total_score = 0.0;
    size_t len = strlen(sequence);
    
    for (size_t i = 0; i < len; i++) {
        total_score += get_chou_fasman_score(sequence[i]);
    }
    
    return total_score / (double)len;
}

// Atomic Solvation Parameter lookup (Free energy contribution in kcal/mol per residue)
double get_solvation_parameter(char aa) {
    switch (toupper((unsigned char)aa)) {
        case 'I': case 'L': case 'V': case 'F': return -2.5; 
        case 'W': case 'Y': case 'M': return -2.0;
        case 'A': case 'C': return -0.5;
        case 'G': case 'P': case 'S': case 'T': return 0.5;  
        case 'H': case 'Q': case 'N': return 1.5;
        case 'D': case 'E': case 'K': case 'R': return 3.0;  
        default: return 0.0;
    }
}

double calculate_solvation_energy(const char *sequence) {
    if (!sequence || *sequence == '\0') return 0.0;
    
    double delta_g = 0.0;
    size_t len = strlen(sequence);
    
    for (size_t i = 0; i < len; i++) {
        delta_g += get_solvation_parameter(sequence[i]);
    }
    
    return delta_g; 
}

// Sequence alignment using simple local Hamming-distance match
double calculate_alignment_score(const char *variant, const char *profile) {
    if (!variant || !profile) return 0.0;
    size_t v_len = strlen(variant);
    size_t p_len = strlen(profile);
    size_t min_len = (v_len < p_len) ? v_len : p_len;
    if (min_len == 0) return 0.0;

    double matches = 0.0;
    for (size_t i = 0; i < min_len; i++) {
        if (toupper((unsigned char)variant[i]) == toupper((unsigned char)profile[i])) {
            matches += 1.0;
        }
    }
    return matches / (double)min_len;
}

/**
 * Master Biophysical Fitness Evaluator
 * Maximizes target alignment, alpha-helix conformation, and hydrophobic moment.
 * Minimizes solvation energy and exponentially penalizes decoy binding (Albumin & NCAM1).
 */

static double clamp01(double x)
{
    if (x < 0.0) return 0.0;
    if (x > 1.0) return 1.0;
    return x;
}

/*
 * Converts a value from [min_value, max_value] into [0, 1].
 * Returns 0.5 when the range is invalid.
 */
static double normalize_range(double value,
                              double min_value,
                              double max_value)
{
    if (max_value <= min_value)
        return 0.5;

    return clamp01(
        (value - min_value) /
        (max_value - min_value)
    );
}

/*
 * Bounded penalty for values far from a neutral reference.
 * The farther the metric moves from the reference, the larger
 * the penalty, but the result is always in [0, 1].
 */
static double deviation_penalty(double value,
                                double reference,
                                double scale)
{
    if (scale <= 0.0)
        return 0.0;

    double d = fabs(value - reference) / scale;

    return d / (1.0 + d);
}

void evaluate_fitness(
    Variant *v,
    const char *target,
    const char *decoy1,
    const char *decoy2,
    void *params
) {
    if (v == NULL || v->sequence == NULL) {
        return;
    }

    (void)params;

    v->helix_propensity =
        calculate_chou_fasman(v->sequence);

    v->solvation_energy =
        calculate_solvation_energy(v->sequence);

    v->hydrophobic_moment =
        calculate_eisenberg_moment(v->sequence);

    /* Sequence identity is diagnostic, not binding evidence. */
    double target_score =
        (target != NULL && target[0] != '\0')
        ? calculate_alignment_score(v->sequence, target)
        : -1.0;

    double decoy1_score =
        (decoy1 != NULL && decoy1[0] != '\0')
        ? calculate_alignment_score(v->sequence, decoy1)
        : -1.0;

    double decoy2_score =
        (decoy2 != NULL && decoy2[0] != '\0')
        ? calculate_alignment_score(v->sequence, decoy2)
        : -1.0;

    charge_summary charge_smry = {0};

    if (compute_charge_profile(
            v->sequence, 2, &charge_smry
        ) != 0) {

        v->fitness_score = -1.0;
        v->target_alignment = target_score;
        v->decoy_penalty = -1.0;
        v->charge_penalty = -1.0;
        v->charge_density = -1.0;
        return;
    }

    double decoy_penalty =
        (decoy1_score >= 0.0 && decoy2_score >= 0.0)
        ? exp(1.5 * decoy1_score)
          + exp(1.5 * decoy2_score)
        : -1.0;

    v->target_alignment = target_score;
    v->decoy_penalty = decoy_penalty;
    v->charge_penalty = charge_smry.penalty;
    v->charge_density = charge_smry.max_patch_density;

    double helix_component = normalize_range(
        v->helix_propensity, 0.50, 1.42
    );

    double hydrophobic_penalty = deviation_penalty(
        v->hydrophobic_moment, 0.35, 0.35
    );

    double solvation_penalty = deviation_penalty(
        v->solvation_energy, 0.0, 20.0
    );

    double charge_component = clamp01(
        charge_smry.penalty / 10.0
    );

    double fitness =
          0.50 * helix_component
        + 0.30 * (1.0 - solvation_penalty)
        + 0.20 * (1.0 - charge_component)
        - 0.10 * hydrophobic_penalty;

    v->fitness_score = clamp01(fitness);
}

/* ============================================================================
 * DATA STRUCTURE LINKING INTERFACES
 * ============================================================================
 */

Variant init_variant(size_t initial_capacity) {
    Variant v;
    v.sequence = (char *)malloc(initial_capacity * sizeof(char));
    if (!v.sequence) {
        fprintf(stderr, "FATAL ERROR: Out of memory during init_variant allocation\n");
        exit(EXIT_FAILURE);
    }
    v.sequence[0] = '\0'; 
    v.length = 0;
    v.capacity = initial_capacity;
    v.fitness_score = 0.0;
    v.solvation_energy = 0.0;
    v.hydrophobic_moment = 0.0;
    v.helix_propensity = 0.0;
    return v;
}

void append_sequence(Variant *v, const char *chunk) {
    if (!v || !chunk) return;
    
    size_t chunk_len = strlen(chunk);
    size_t required_capacity = v->length + chunk_len + 1; 
    
    if (required_capacity > v->capacity) {
        size_t new_capacity = v->capacity * 2;
        if (new_capacity < required_capacity) {
            new_capacity = required_capacity;
        }
        
        char *new_seq = (char *)realloc(v->sequence, new_capacity * sizeof(char));
        if (!new_seq) {
            fprintf(stderr, "FATAL ERROR: Out of memory during append_sequence realloc\n");
            exit(EXIT_FAILURE);
        }
        v->sequence = new_seq;
        v->capacity = new_capacity;
    }
    
    strcpy(v->sequence + v->length, chunk);
    v->length += chunk_len;
}