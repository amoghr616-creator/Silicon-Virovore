# HybriDock-Pep — Installation Guide

This document walks you through setting up both conda environments and the
non-redistributable third-party tools required to run HybriDock-Pep end-to-end.

> **Just want it installed?** Run `./install.sh` (Linux/WSL2/macOS) or
> `install.bat` (Windows) from the repo root — it automates every step below
> including receptor-prep tooling (see Step 4), and finishes by launching a
> guided terminal UI. The rest of this document is the manual walkthrough,
> useful if you want to understand or control each step individually, or if
> `install.sh` doesn't fit your setup.

> **Platform summary:**
> | Platform | Stage 1 (RAPiDock) | Stage 2 (scoring/MM-GBSA) |
> |---|---|---|
> | Linux x86-64 + CUDA | ✅ CUDA (full speed) | ✅ |
> | WSL2 + CUDA passthrough | ✅ CUDA | ✅ |
> | macOS Apple Silicon (M1–M4) | ✅ MPS (~10× slower than CUDA) | ✅ (native, no Rosetta) |
> | macOS Intel | ✅ CPU (slow, use `--n-samples 10`) | ✅ |
> | Google Colab (T4/L4/A100) | ✅ CUDA — see [Google Colab](#google-colab) | ✅ |
> | Native Windows (no WSL) | ❌ (needs the Linux/WSL2/macOS CUDA or MPS stack) | ✅ (`conda env create -f envs/score-env.yml` — CI-verified) |
>
> `--input-poses` lets you skip Stage 1 entirely and supply pre-generated poses
> from a CUDA machine to run only Stage 2 scoring on any platform, including
> native Windows.
>
> **Windows users:** `install.bat` sets up WSL2 and runs the full pipeline
> there (Stage 1 + Stage 2, CUDA passthrough) — this is the path to use if you
> want everything working with one script. **After it finishes, run everything
> else — `conda activate`, `hybridock-pep`, `./launch_ui.sh` — inside the
> WSL2/Ubuntu terminal** (Start menu → search "Ubuntu", or type `wsl` in any
> Windows terminal), not PowerShell/CMD; those commands aren't installed on
> the Windows side. `install.bat` is safe to run again any time (e.g. after a
> `git pull`) — it detects an existing WSL2 distro and skips conda
> environments / model weights that are already present rather than
> recreating them, and it does not need to be re-run for normal day-to-day
> use. If you only need Stage 2 scoring and would rather stay outside WSL2,
> `conda env create -f envs/score-env.yml` now works directly in a native
> Windows conda prompt/PowerShell (Vina is built from source there against a
> MinGW-w64 + Boost toolchain — see the `conda-platforms` Windows job in
> `.github/workflows/ci.yml` for exactly how CI does this, or run
> `scripts/patch_vina_windows_setup.py` yourself if installing outside conda).

---

## Google Colab

[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/Tasty-Ramen2010/hybridock-pep/blob/master/notebooks/HybriDock_Pep_Colab.ipynb)

`notebooks/HybriDock_Pep_Colab.ipynb` runs the full pipeline on a free Colab T4.
Open it, set *Runtime > Change runtime type > T4 GPU*, and run the cells in
order — the notebook drives everything below for you.

To set up an existing Colab session by hand instead:

```bash
!git clone --recursive https://github.com/Tasty-Ramen2010/hybridock-pep.git
%cd hybridock-pep
!bash scripts/colab_setup.sh --cache-dir /content/drive/MyDrive/hybridock-pep/cache
```

`scripts/colab_setup.sh` is the headless Colab counterpart to `install.sh`.
The differences that matter:

- **micromamba, not Miniforge**, with its root prefix at `/opt/conda` — a prefix
  `rapidock_runner.py` and `toolpath.py` already probe, so both envs are found
  with no extra configuration.
- **GPU-matched PyTorch.** Colab hands out T4 (compute capability 7.5), L4 (8.9)
  or A100 (8.0) depending on tier and load. CC 8.0+ gets the same
  torch 2.7.0 + cu128 build `install.sh` uses; a T4 gets torch 2.6.0 + cu124,
  which unambiguously ships sm_75 kernels and has matching PyG wheels. The
  script then launches a real CUDA kernel to confirm, and falls back
  automatically if it fails — a mismatched build imports fine and only dies at
  the first kernel launch, well into a dock.
- **`--cache-dir`** points the torch/ESM cache and the RAPiDock checkpoints at a
  persistent directory (typically a mounted Drive folder), so the ~2.5 GB ESM-2
  download happens once per account rather than once per session. The conda
  environments are rebuilt every session regardless — about 17 minutes, of
  which ~10 is pre-computing RAPiDock's SO(3)/torus lookup tables (see below).
- **No terminal UI at the end.** `install.sh` finishes by exec'ing
  `./launch_ui.sh`, which a notebook kernel cannot host.

Flags: `--cache-dir DIR`, `--backend cuda|cpu`, `--skip-rapidock`, `--lite`, `--force`.

### `--lite` — install only what plain docking reads

`--lite` reclaims about 260 MB:

| Skipped | Size | What you lose |
|---|---|---|
| Boost C++ headers, after Vina compiles | 188 MB | nothing at runtime — Vina links the ~11 MB of shared libs in `lib/`, which stay |
| `rapidock_global.pt` | 54 MB | `dock --blind` (site-directed docking is unaffected) |
| autogrid + openbabel | ~20 MB | `--scoring ad4`, and the obabel fallback if meeko cannot run |

Be clear about the ceiling: an install is dominated by **PyTorch** and the **2.4 GB ESM-2
language model**, and docking needs both, so no flag removes them. `--lite` trims the margin,
not the mass. Trimming repo files saves even less — a full clone is only ~21 MB packed.

If you only need to **score** poses you already have, `--skip-rapidock` is the real saving:
it skips the entire sampling environment and the ESM-2 download, several gigabytes, at the
cost of not being able to dock. `./install.sh --lite` does the checkpoint half of this locally.

### Working from a shell instead of the notebook

The notebook is one way in, not the only one. `colab_setup.sh` finishes by
shimming `hybridock-pep` and `hybridock-tui` into `/usr/local/bin` and adding a
line to `~/.bashrc` that sources `/content/hybridock_env.sh`, so every new shell
— the Colab Pro terminal, an `%xterm` cell, a bare `!bash` — has the commands on
`PATH` with `RAPIDOCK_PYTHON` and `RAPIDOCK_DIR` already set. Nothing to
activate, and every command in the README works verbatim:

```bash
cd /content/hybridock-pep
hybridock-tui        # the guided UI — a real terminal can host it, a cell cannot
hybridock-pep dock --peptide ETFSDLWKLLPE --receptor data/pdbs/1YCR_mdm2.pdb \
    --site 25.20 -25.61 -7.97 --box 30 --n-samples 100 --output-dir runs/my_run
```

Free-tier Colab has no terminal button; `!pip install -q colab-xterm` then
`%load_ext colabxterm` and `%xterm` gives you one inside a cell.

`hybridock-tui` is full-screen, and an in-notebook terminal is a smaller and
less capable terminal than a real one. If it renders badly, `./launch_ui.sh
--cli` is the same wizard as plain question-and-answer prompts, and
`./launch_ui.sh --print` builds the command without running it.

Colab caveats: a session is capped at roughly 12 hours and idle sessions get
reclaimed, so mount Drive before starting anything long (`--ultra`, large
`--n-samples`); and both environments plus weights come to ~15 GB of the
runtime's disk.

---

## Prerequisites

- **conda:** [Miniforge](https://github.com/conda-forge/miniforge/releases)
  strongly preferred over full Anaconda. Any conda ≥ 23.x works.
- **Disk space:** ~20 GB for both environments (PyTorch + optional CUDA libs dominate).
- **For CUDA Stage 1:** NVIDIA driver ≥ 550, CUDA 12.8 runtime, compute capability ≥ 8.0
  (RTX 5070 is CC 12.0 — Blackwell-compatible via PyTorch 2.7+cu128).
- **For macOS Stage 1 (MPS):** macOS 12.3+ (Monterey) on Apple Silicon. MPS is automatic.

---

## Step 1 — Create the scoring environment (all platforms)

`score-env` contains Vina, OpenMM, scikit-learn, RDKit, meeko, pdbfixer, and the
HybriDock-Pep package itself.

```bash
conda env create -f envs/score-env.yml
conda activate score-env
pip install -e .
```

Verify: `hybridock-pep --help` prints the CLI usage.

---

## Step 2 — Create the GPU/inference sampling environment

`rapidock` contains the RAPiDock-Reloaded diffusion model stack (Python 3.10,
MDAnalysis, e3nn, RDKit, fair-esm). PyTorch + PyG are installed via pip after
the base env is created because the CUDA wheels are only on `download.pytorch.org`.

### Step 2a — Create the base conda env

**Linux / WSL2:**
```bash
conda env create -f envs/rapidock-env.yml
```

**macOS (Apple Silicon or Intel):**
```bash
conda env create -f envs/rapidock-env-macos.yml
```

### Step 2b — Install PyTorch + PyG (platform-specific)

**Linux / WSL2 with CUDA 12.8 (RTX 5070 / any CUDA 12.x GPU):**
```bash
conda run -n rapidock pip install torch==2.7.0 \
    --index-url https://download.pytorch.org/whl/cu128

conda run -n rapidock pip install \
    torch-geometric \
    torch-scatter torch-sparse torch-cluster torch-spline-conv \
    -f https://data.pyg.org/whl/torch-2.7.0+cu128.html
```

**macOS Apple Silicon (MPS) or Intel (CPU):**
```bash
conda run -n rapidock pip install torch torchvision torchaudio

conda run -n rapidock pip install \
    torch-scatter torch-sparse torch-cluster torch_geometric
```

> **Why separate pip steps?** PyTorch CUDA wheels (`+cu128`) are only on
> `download.pytorch.org`, not conda-forge. Mixing them into the conda solve
> causes `PackagesNotFoundError`. The two-phase approach always works cleanly.

### Step 2c — Verify PyTorch sees your device

```bash
# Should print True + device name on CUDA machines
conda run -n rapidock python3 -c "
import torch
print('CUDA:', torch.cuda.is_available())
if torch.cuda.is_available():
    print('Device:', torch.cuda.get_device_name(0))
    print('Compute cap:', torch.cuda.get_device_capability(0))
# macOS Apple Silicon
if hasattr(torch.backends, 'mps'):
    print('MPS available:', torch.backends.mps.is_available())
"
```

Expected on RTX 5070: `CUDA: True, Device: NVIDIA GeForce RTX 5070, Compute cap: (12, 0)`
Expected on M-series Mac: `CUDA: False, MPS available: True`

---

## Step 3 — Initialise the RAPiDock-Reloaded submodule

RAPiDock-Reloaded is bundled at `third_party/RAPiDock/` as a git submodule.
If you cloned with `--recursive` it's already present; otherwise:

```bash
git submodule update --init --recursive
```

No `pip install` needed — the runner imports directly from that path.

### Step 3b — Install the model weights (no download)

The two pre-trained checkpoints are **committed to this repository** under
`weights/` (54 MB each, CC-BY-4.0 — see [`weights/README.md`](weights/README.md)),
so a `git clone` already has them. `./install.sh` copies them into place; this
section is only needed for a manual install, or to repair a partial one.

```bash
bash scripts/install_weights.sh          # both checkpoints
bash scripts/install_weights.sh --lite   # rapidock_local.pt only
```

That script copies `weights/*.pt` to the directory RAPiDock resolves a bare
`--ckpt` filename against, and verifies the SHA-256 of each file:

```
third_party/RAPiDock/train_models/CGTensorProductEquivariantModel/
  rapidock_local.pt    ← required — site-directed docking
  rapidock_global.pt   ← required — the `--blind` pocket-search pass
  longer_local.pt      ← optional — long-peptide specialized checkpoint (13+ residues);
                          `dock` silently falls back to rapidock_local.pt with a logged
                          warning if absent. See docs/architecture.md §3.2. It has never
                          been published — no fine-tuned checkpoint in this project's
                          history beat the base model — so nothing can fetch it.
```

Both required checkpoints are installed unconditionally: `rapidock_global.pt` is
hard-coded by the `--blind` pocket-search path, so an install that skips it
leaves `dock --blind` broken while ordinary docking looks fine.

If `weights/` is missing from your checkout (an incomplete clone, or a source
tarball that dropped the large files), the script falls back to downloading from
[Zenodo record 14193621](https://zenodo.org/records/14193621) — the same files,
same checksums. That used to be the default path and is now only the fallback,
because it was the one install step that had to reach a host outside GitHub and
PyPI, and `zenodo.org` is blocked on some school and institutional networks.

The runner raises `FileNotFoundError` naming the missing checkpoint and its
expected directory before launching RAPiDock — so a skipped file fails
immediately rather than as an opaque subprocess exit partway into Stage 1. It
also tries `weights/` itself first, so a plain `git clone --recursive` can dock
even if neither installer was run.

> **Alternate weight path:** Set `RAPIDOCK_MODEL_DIR=/abs/path` to override.
> Set `RAPIDOCK_DIR=/abs/path` to override the submodule location entirely.

Verify the import chain works:

```bash
conda run -n rapidock python3 -c "
import sys; sys.path.insert(0, 'third_party/RAPiDock')
from utils.inference_parsing import get_parser
print('RAPiDock-Reloaded: OK')
"
```

---

## Step 4 — Receptor-prep tooling (no license, no manual download)

ADFRsuite is **not required**. Two pip/conda packages replace it, both with
native Apple Silicon builds:

| what it does | tool | install |
|---|---|---|
| receptor PDB → PDBQT | meeko's `mk_prepare_receptor.py` | already in `envs/score-env.yml` (`meeko>=0.7`) |
| AutoDock4 grid maps | `autogrid4` | `conda install -c conda-forge autogrid` |

`install.sh` sets both up for you. To do it by hand:

```bash
conda activate score-env
conda install -c conda-forge autogrid     # only needed for --scoring ad4
pip install 'meeko>=0.7'                  # usually already present
```

Verify:

```bash
which mk_prepare_receptor.py   # → score-env/bin/mk_prepare_receptor.py
which autogrid4                # → score-env/bin/autogrid4
```

> `AD4_parameters.dat` is **not** needed. A GPF's `parameter_file` directive is
> optional, and autogrid4 falls back to its built-in AD4.2 parameters. That file
> only ever shipped with ADFRsuite, and needing it was the sole reason ADFRsuite
> was a hard requirement.

### If you already have ADFRsuite

It is still used automatically when `prepare_receptor` is on PATH, which keeps
results identical to earlier installs. Nothing to change. Note that ADFRsuite
ships a Python 2.7 binary named `python`, so always call `python3` explicitly
when its `bin/` is on your PATH.

## Step 5 — Install PyRosetta (optional, rarely needed)

Used only for RAPiDock's optional post-relax step. **Default is OFF** in
HybriDock-Pep (CLAUDE.md §2.5 — C-terminal cysteine alignment bug). Skip this
unless you specifically need PyRosetta-based relaxation on non-cysteine peptides.

**Obtain license + wheel:** <https://www.pyrosetta.org/downloads>

```bash
conda activate rapidock
pip install pyrosetta-*.whl
```

---

## Step 6 — Verify the full installation

```bash
conda activate score-env
bash scripts/smoke_test.sh
```

**Linux/WSL2 expected output:**
```
[PASS] CUDA compute capability 12.0 >= 12.0
[PASS] prepare_receptor found on PATH
[PASS] AutoDock Vina Python API 1.2.x >= 1.2.5
Results: 3 passed, 0 warnings, 0 failed
```

**macOS expected output:**
```
[INFO] No CUDA GPU — MPS (Apple Silicon) or CPU will be used for Stage 1
[PASS] prepare_receptor found on PATH (Rosetta 2)
[PASS] AutoDock Vina Python API 1.2.x >= 1.2.5
Results: 2 passed, 1 info, 0 failed
```

Run the unit test suite:

```bash
pytest                         # fast unit tests (~5 s)
pytest -m slow                 # add integration tests (~2 min)
pytest --cov=hybridock_pep     # with coverage report
```

---

## macOS quick-start end-to-end

Once both environments are set up, a full dock run on macOS Apple Silicon:

```bash
# Stage 1 + 2: 20-pose run via MPS (~2 min on M3, ~25 min on Intel CPU)
hybridock-pep dock \
    --peptide LISAAALAAIFAAALAC \
    --receptor data/pdbs/1T2D_receptor.pdb \
    --site 24.84 22.73 41.69 --box 30 \
    --n-samples 20 \
    --output-dir runs/pfldh_macos_test

# Stage 2 only — score poses generated on a CUDA machine
hybridock-pep dock \
    --input-poses /path/to/poses_from_cuda_machine/ \
    --receptor data/pdbs/1T2D_receptor.pdb \
    --site 24.84 22.73 41.69 --box 30 \
    --output-dir runs/pfldh_scored
```

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `libpython2.7.so.1.0` error in `conda run` | a stray ADFRsuite `python` shadows conda | Always use `python3` explicitly |
| `autogrid4` segfaults immediately | relative `parameter_file` path | Already fixed in code (the line is omitted entirely unless ADFRsuite supplies an absolute path) |
| `No module named 'torch'` in rapidock env | PyTorch not installed (Step 2b skipped) | Re-run Step 2b for your platform |
| `CUDA capability sm_120 not compatible` | PyTorch < 2.6 | Re-run Step 2b with `torch==2.7.0` |
| `HIS residue has the wrong set of atoms` | pdbfixer edge case on RCSB PDB | Already handled gracefully in `receptor.py` |
| `babel: command not found` | OpenBabel missing | `conda install -c conda-forge openbabel` (only a last-resort fallback; meeko is preferred) |
| MPS fallback warnings in Stage 1 | Ops not yet on Metal | Normal — `PYTORCH_ENABLE_MPS_FALLBACK=1` already set by inference.py |
| `torch-scatter` ImportError on macOS | Wrong PyG install command used | Use the macOS pip command from Step 2b (no `+cu128`) |
| Stage 1 very slow on macOS Intel | No MPS, running on CPU | Expected; use `--n-samples 10` or use `--input-poses` bypass |
